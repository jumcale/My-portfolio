Place your resume PDF file here as 'resume.pdf' to enable the download feature.

You can upload your resume PDF through the file manager or via the admin dashboard settings.
